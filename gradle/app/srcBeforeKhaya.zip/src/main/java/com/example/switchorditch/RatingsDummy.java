package com.example.switchorditch;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class RatingsDummy extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ratings_dummy);
    }
}